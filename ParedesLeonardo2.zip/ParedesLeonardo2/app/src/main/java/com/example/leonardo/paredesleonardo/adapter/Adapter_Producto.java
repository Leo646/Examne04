package com.example.leonardo.paredesleonardo.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.leonardo.paredesleonardo.R;
import com.example.leonardo.paredesleonardo.modelo.Producto;

import java.util.ArrayList;

public class Adapter_Producto extends BaseAdapter {
    private Context contexto;
    private ArrayList<Producto> listaProductos;
    public Adapter_Producto(Context contexto, ArrayList<Producto> listaProductos){
        this.contexto=contexto;
        this.listaProductos=listaProductos;

    }
    @Override
    public int getCount() {
        return listaProductos.size();
    }

    @Override
    public Object getItem(int position) {
        return listaProductos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null)
            convertView=View.inflate(contexto,R.layout.display_produtos, null);
        TextView textNombre= convertView.findViewById(R.id.lblhamburguesa);
        TextView textCodigo= convertView.findViewById(R.id.lblcerveza);
        TextView textPrecio= convertView.findViewById(R.id.lblensalada);
        TextView textEXistencia= convertView.findViewById(R.id.lblsalchipapa);
        Producto producto=listaProductos.get(position);
        textNombre.setText(String.valueOf(producto.getHamburguesa()));
        textCodigo.setText(String.valueOf(producto.getCerveza()));
        textPrecio.setText(String.valueOf(producto.getEnsalada()));
        textEXistencia.setText(String.valueOf(producto.getSalchipapa()));

        return convertView;
    }
}


