package com.example.leonardo.paredesleonardo;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.leonardo.paredesleonardo.adapter.Adapter_Producto;
import com.example.leonardo.paredesleonardo.modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class ActividadPrincipal extends AppCompatActivity implements View.OnClickListener {
    EditText n1,n2,n3,n4;
    Button boton, calcularal;
    TextView presentar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_principal);
        n1=(EditText) findViewById(R.id.txthamburguesa);
        n2=(EditText) findViewById(R.id.txtcerveza);
        n3=(EditText) findViewById(R.id.txtensalada);
        n4=(EditText) findViewById(R.id.txtsalchipapa);
        boton=(Button) findViewById(R.id.btnCrear);
        calcularal=(Button) findViewById(R.id.btnCalcular);
        presentar=(TextView) findViewById(R.id.lblpresentar);
        boton.setOnClickListener(this);
        calcularal.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnCrear:
                final Dialog dlgCrearProducto=new Dialog(ActividadPrincipal.this);
                dlgCrearProducto.setContentView(R.layout.dlg_dialogo);
                final EditText nommbre=(EditText) dlgCrearProducto.findViewById(R.id.txthamburguesa);
                final EditText codigo=(EditText) dlgCrearProducto.findViewById(R.id.txtcerveza);
                final EditText precio=(EditText) dlgCrearProducto.findViewById(R.id.txtensalada);
                final EditText existencia=(EditText) dlgCrearProducto.findViewById(R.id.txtsalchipapa);
                Button guardar= (Button) dlgCrearProducto.findViewById(R.id.btnguardar);
                guardar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Producto p=new Producto();
                        p.setHamburguesa(Double.parseDouble(nommbre.getText().toString()));
                        p.setCerveza(Double.parseDouble(codigo.getText().toString()));
                        p.setEnsalada(Double.parseDouble(precio.getText().toString()));
                        p.setSalchipapa(Double.parseDouble(existencia.getText().toString()));
                        dlgCrearProducto.hide();
                        p.save();

                    }
                });
                dlgCrearProducto.show();
                break;
            case R.id.btnCalcular:
                Producto  ver= new Producto();
                String no= ver.obtenerProducto().toString();
                ver.getHamburguesa();
                presentar.setText(" "+ no+"\n");

        }

    }

}
