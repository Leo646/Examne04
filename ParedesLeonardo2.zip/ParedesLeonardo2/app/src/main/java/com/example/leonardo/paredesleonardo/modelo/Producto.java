package com.example.leonardo.paredesleonardo.modelo;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;
import com.activeandroid.query.Select;

import java.util.List;

@Table(name="producto")
public class Producto  extends Model {
    @Column(name = "hamburguesa", notNull = true)
    private Double Hamburguesa;
    @Column(name = "cerveza", notNull = true)
    private Double Cerveza;
    @Column(name = "ensalada", notNull = true)
    private Double Ensalada;
    @Column(name = "salchipapa", notNull = true)
    private Double Salchipapa;
    public Producto() {
        super();

    }

    public Producto(Double hamburguesa, Double cerveza, Double ensalada, Double salchipapa) {
        super();
        this.Hamburguesa = hamburguesa;
        this.Cerveza = cerveza;
        this.Ensalada = ensalada;
        this.Salchipapa = salchipapa;
    }

    public Double getHamburguesa() {
        return Hamburguesa;
    }

    public void setHamburguesa(Double hamburguesa) {
        Hamburguesa = hamburguesa;
    }

    public Double getCerveza() {
        return Cerveza;
    }

    public void setCerveza(Double cerveza) {
        Cerveza = cerveza;
    }

    public Double getEnsalada() {
        return Ensalada;
    }

    public void setEnsalada(Double ensalada) {
        Ensalada = ensalada;
    }

    public Double getSalchipapa() {
        return Salchipapa;
    }

    public void setSalchipapa(Double salchipapa) {
        Salchipapa = salchipapa;
    }
    public List<Producto> obtenerProducto(){

        return new Select().from(Producto.class).execute();

    }

    @Override
    public String toString() {
        return
                "Hamburguesa=" + Hamburguesa +
                ", Cerveza=" + Cerveza +
                ", Ensalada=" + Ensalada +
                ", Salchipapa=" + Salchipapa
                ;
    }
}
