package com.example.leonardo.paredesleonardo.config;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.app.Application;

public class MyAplication extends Application{
    @Override
    public void onCreate() {
        super.onCreate();
        ActiveAndroid.initialize(this);
    }
}
